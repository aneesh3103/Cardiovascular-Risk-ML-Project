import pandas as pd
from sklearn.linear_model import LogisticRegression
import pickle

# Sample data - replace with your dataset
data = {
    'age': [25, 35, 45, 50, 23, 43, 54, 32, 34, 67],
    'cholesterol': [200, 230, 250, 270, 190, 210, 240, 220, 225, 260],
    'target': [0, 0, 1, 1, 0, 0, 1, 0, 0, 1]
}
df = pd.DataFrame(data)

X = df[['age', 'cholesterol']]
y = df['target']

model = LogisticRegression()
model.fit(X, y)

# Save the model
pickle.dump(model, open('model.pkl', 'wb'))
